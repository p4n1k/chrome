while [ 1 ]; do
./cpuminer-sse2 -a yescryptR16 -o stratum+tcp://yescryptR16.asia.mine.zergpool.com:6333 -u qgUHBLFGsos52xRT6z1HvLgG75mmBzi3uy -p c=QOGE,mc=QOGE,ID=cpu3900x
sleep 5
done